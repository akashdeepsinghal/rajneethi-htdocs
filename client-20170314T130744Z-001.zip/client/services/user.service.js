var app = angular.module('rajneethi');
app.service('userService', function($http) {
    this.getUserDetails = function() {
        return $http.get('/api/details');
    };
    this.createUserDetails = function(userdetails) {
        return $http.post('/api/details', userdetails);

    };
    this.deleteUserDetails = function(id) {
        return $http.delete('/api/details/' + id)
    };
    this.updateUserDetails = function(id, userdetails) {
        return $http.put('/api/details/' + id, userdetails)
    };
    this.loginUser = function(userdetails) {
        return $http.post('/api/login/', userdetails)

    };
    
});
