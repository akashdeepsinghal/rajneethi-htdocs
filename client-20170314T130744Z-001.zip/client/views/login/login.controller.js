var app = angular.module('rajneethi');

app.controller('loginController', function($scope, $location, userService) {
    $scope.loginValidUser = function() {
        userService.loginUser($scope.userdetails)
            .success(function(data) {
                // console.log(data)
                // console.log(data._id)

                $location.path('/profile/' + data._id)
            })
            .error(function(data, status) {
                console.log(status)
                if (status == 404) {
                    $scope.error = 'Invalid Username and Password!';
                }

            });

    }
});


// app.run(function($rootScope, $location) {
//     $rootScope.$on('$locationChangeSuccess', function() {
//         if($rootScope.previousLocation == $location.path()) {
//             alert("1111111111111111111")
//             alert($location.path())
//             console.log("Back Button Pressed");
//         }
//         $rootScope.previousLocation = $rootScope.actualLocation;
//         $rootScope.actualLocation = $location.path();
//     });
// });

