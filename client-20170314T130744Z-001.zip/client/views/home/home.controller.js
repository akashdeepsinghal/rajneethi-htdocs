var app = angular.module('rajneethi');

app.controller('homeController', function($scope, $location, userService) {
  
});

