 var app = angular.module('rajneethi');

 app.controller('clientProfileCtrl', function($scope) {
     $scope.projectType = [
             "Primary Education",
             "Higher Education",
             "Sports and Youth Services",
             "Health", "Development of Women and Child",
             "Social welfare / Backward Class / Minorities",
             "Animal Husbandry",
             "Horticulture",
             "Home",
             "Infrastructure developments",
             "Facilities in notified Slum Areas",
             "Providing RO water in villages",
             "Tourism",
             "Construction of Samudaya Bhavan",
             "Construction of Public Library Building and providing mobile"
         ];


          //   Primary Education: [
          //        Construction of class rooms,
          //        Construction of compound walls,
          //        Development of play grounds,
          //        Construction of full pledged libraries with all necessary equipments,
          //        Construction of laboratories,
          //        Construction of open air theatres,
          //        Construction of cycle stands,
          //        Construction of teachers’ quarters near school,
          //        Providing drinking water facilities like RO,
          //        Providing computers, printers etc,
          //        Providing sports and teaching materials,

          // ],
     


 });
