var app = angular.module('rajneethi', ['ngRoute','ngFileUpload']);

app.config(function($routeProvider) {
    $routeProvider
        .when('/', {
            templateUrl: 'views/home/home.html',
            controller: 'homeController'
        })
        .when('/login', {
            templateUrl: 'views/login/login.html',
            controller: 'loginController'
        })
        .when('/signup', {
            templateUrl: 'views/signup/signup.html',
            controller: 'signupController'
        })            
         .when('/clientprofile', {
            templateUrl: 'views/clientProfile/clientProfile.html',
            controller: 'clientProfileCtrl'
        })
         .when('/imageupload', {
            templateUrl: 'views/imageUpload/imageUpload.html',
            controller: 'imageUploadCtrl'
        })
         .when('/caste-equation/:id', {
            templateUrl: 'views/casteEquation/casteEquation.html',
            controller: 'casteEquationCtrl'
        })
        .otherwise({
            redirectTo: '/'
        });
});
