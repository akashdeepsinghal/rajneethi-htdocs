//scripts.js
$(document).ready(function(){
$("body").backstretch("images/hero.png");
});